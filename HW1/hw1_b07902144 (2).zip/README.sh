# DIP Homework Assignment #1
# Name: 彭約博
# ID #: B07902144
# email: b07902144@csie.ntu.edu.tw

python3 hw1.py  -i hw1_sample_images/sample1.jpg -o result/1_result.jpg
python3 hw1.py  -i hw1_sample_images/sample1.jpg -o result/2_result.jpg
python3 hw1.py  -i hw1_sample_images/sample2.jpg -o result/3_result.jpg
python3 hw1.py  -i 	     result/3_result.jpg -o result/4_result.jpg
python3 hw1.py  -i hw1_sample_images/sample3.jpg -o result/5_result.jpg
python3 hw1.py  -i hw1_sample_images/sample3.jpg -o result/6_result.jpg
python3 hw1.py  -i hw1_sample_images/sample4.jpg -o result/7_result.jpg
python3 hw1.py  -i hw1_sample_images/sample6.jpg -o result/8_result.jpg
python3 hw1.py  -i hw1_sample_images/sample7.jpg -o result/9_result.jpg

