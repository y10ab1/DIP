# DIP Homework Assignment #2
# Name: 彭約博
# ID #: B07902144
# email: b07902144@csie.ntu.edu.tw

python3 hw2.py  -i hw2_sample_images/sample1.jpg -o result/result1.jpg
python3 hw2.py  -i hw2_sample_images/sample1.jpg -o result/result2.jpg
python3 hw2.py  -i hw2_sample_images/sample1.jpg -o result/result3.jpg
python3 hw2.py  -i hw2_sample_images/sample1.jpg -o result/result4.jpg
python3 hw2.py  -i 	      result/result4.jpg -o result/result5.jpg
python3 hw2.py  -i hw2_sample_images/sample2.jpg -o result/result6.jpg
python3 hw2.py  -i hw2_sample_images/sample3.jpg -o result/result7.jpg
python3 hw2.py  -i hw2_sample_images/sample5.jpg -o result/result8.jpg

